Griffin.WebServer
=================

A web server built on top of Griffin.Networking.

# Current features

* Form/File handling, i.e. body decoding (multipart & UrlEncoded)
* Authentication (digest & basic)
* Static file handling (including partial downloads and caching)
* Custom modules
* Model binders.

# Installation

    install-package Griffin.WebServer
	
Do note that it's a beta.
	
# Links

* [Forum / Mailing list](https://groups.google.com/forum/#!forum/griffin-webserver)
