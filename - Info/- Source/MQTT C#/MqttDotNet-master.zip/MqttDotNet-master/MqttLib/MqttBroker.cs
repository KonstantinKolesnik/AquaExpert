using System;
using System.Collections.Generic;
using System.Text;
using MqttLib.Logger;
using MqttLib.Core;

namespace MqttLib
{
  /// <summary>
  /// Used to instantiate a new MQTT Broker.
  /// </summary>
  internal class MqttBroker
  {
    MqttBroker()
    {

    }
  }
}
