﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace System.Collections
{
	class Hashtable : Dictionary<object, object>
	{

	}
}
