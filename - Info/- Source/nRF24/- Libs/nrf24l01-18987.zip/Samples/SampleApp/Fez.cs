﻿namespace Gralin.NETMF.Nordic
{
    public enum Fez
    {
        Mini = 1,
        Domino = 2,
        Cobra = 5
    }
}