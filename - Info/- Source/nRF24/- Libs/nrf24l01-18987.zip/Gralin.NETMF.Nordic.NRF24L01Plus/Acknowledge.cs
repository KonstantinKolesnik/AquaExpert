﻿namespace Gralin.NETMF.Nordic
{
    public enum Acknowledge
    {
        Yes,
        No
    }
}