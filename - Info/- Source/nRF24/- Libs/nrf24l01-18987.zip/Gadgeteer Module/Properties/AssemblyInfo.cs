﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GTM.Gralin.Nordic")]
[assembly: AssemblyDescription("Driver for Nordic module made by  for Microsoft .NET Gadgeteer")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Nordic")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// This is the assembly version.  It is often useful to keep this constant between major releases where the API changes
// since a dll relying on this dll will need to be recompiled if this changes.
// Suggestion: use a version number X.Y.0.0 where X and Y indicate major version numbers.
[assembly: AssemblyVersion("1.0.0.0")]

// These numbers must be changed whenever a new version of this dll is released, to allow upgrades to proceed correctly.
// Suggestion: Use a version number X.Y.Z.0 where X.Y.Z is the same as the installer version found in Setup\common.wxi
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0.0")]
