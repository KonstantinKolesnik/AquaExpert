#define bitmapdatatype unsigned short*

