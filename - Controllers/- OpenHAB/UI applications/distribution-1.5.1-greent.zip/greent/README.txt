--- INSTALLATION ---
1. Place the "greent" folder in <openhab>/webapps/ folder.
2. Place <openhab>/webapps/greent/greent.items in <openhab>/configurations/items folder.
3. Edit <openhab>/webapps/greent/configs/settings.cfg if necessary.
4. Point your browser to http://your-server:8080/greent/
