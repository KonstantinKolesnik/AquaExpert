/***
 *  This file defines the Sensor library version number 
 *  Normally, contributors should not modify this directly
 *  as it is manaaged by the MySensors Bot.
 */
#ifndef Version_h
#define Version_h

#define LIBRARY_VERSION "1.4.1"

#endif
