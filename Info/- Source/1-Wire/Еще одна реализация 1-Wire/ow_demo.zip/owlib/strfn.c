/*
Useful int-to-str functions module.

See strfn.h for complete info.
*/

void PutIntToStrEx(int num,char numstr[],int StartPos,char NumDgt)
{
    int i;
    char sign=' ';

    if (num<0)
    {
        num=-num;
        sign='-';
    }

    if (!NumDgt)
    {
        if (sign==' ')
            i=StartPos+5;
        else
            i=StartPos+6;

        do
        {
            --i;
            numstr[i]=(num % 10) | 0x30;
        }while (num/=10);

        --i;

        numstr[i]=sign;
    }
    else
    {
        if (sign==' ')
            i=StartPos+NumDgt;
        else
        {
            i=StartPos+NumDgt+1;
            numstr[StartPos]=sign;
            ++StartPos;
        }

        do
        {
            --i;
            numstr[i]=(num % 10) | 0x30;
            num/=10;
        }while (i>StartPos);
    }
}

char NibbleToChar(unsigned char n)
{
    if ((n>=0) && (n<=9))
        return n | 0x30;

    if ((n>=10) && (n<=15))
        return (n-10)+'A';

    return '?';
}

void NumToHex(unsigned char num,unsigned char StartPos,unsigned char hexstr[],unsigned char UsePrefix)
{
    if (UsePrefix)
    {
        hexstr[StartPos]='0';
        hexstr[StartPos+1]='x';
        StartPos+=2;
    }

    hexstr[StartPos]=NibbleToChar((num & 0xF0) >> 4);
    hexstr[StartPos+1]=NibbleToChar(num & 0x0F);
}
