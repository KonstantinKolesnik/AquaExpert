#ifndef _STRFN_H_
#define _STRFN_H_

/*
Useful int-to-str functions module.

Written by YS from we.easyelectronics.ru

You may freely use and redistribute this code any way you want,
but only at your own risk. Author gives no warranty and takes no 
responsibility on anything that could happen while using this code.
*/

/*
This function converts an integer value into its character
representation and stores these characters into 'numstr's
next 6 or 'NumDgt' (see note below) characters from 'StartPos'.

'num'       -   integer to convert to string;

'numstr'    -   target string;

'StartPos'  -   the next 6 characters from 'StartPos' will
                be used for storing 'num' characters. The best
                way is to fill them with spaces before calling
                PutIntToStrEx().
                NOTE:
                If 'NumDgt' is zero, function will always use
                exactly 6 characters.

'NumDgt'    -   Optional number of digits to convert to characters.
                If 'NumDgt' is not zero, only 'NumDgt' charaters
                will be converted and placed to 'numstr'. If 'num'
                has less digits than specified in 'NumDgt', leading
                zeroes will be added.
                NOTE:
                If 'num' is negative, function will use one extra
                character to store sign.
*/
void PutIntToStrEx(int num,char numstr[],int StartPos,char NumDgt);


/*
This function converts a number to its hexadecimal character representation.

num       - number to convert;
StartPos  - function begins to put converted characters to hexstr 
            at this position;
hexstr[]  - string to put characters in;
UsePrefix - when this parameter is nonzero, functionj adds "0x" prefix to 
            converted number.
*/
void NumToHex(unsigned char num,unsigned char StartPos,unsigned char hexstr[],unsigned char UsePrefix);

#endif
