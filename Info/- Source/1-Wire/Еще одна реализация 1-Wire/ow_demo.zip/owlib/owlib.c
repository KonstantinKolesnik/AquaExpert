/*
Software implementation of 1-Wire interface 

demo application - iButton reader.

Reads iButton serial number 
and outputs it through UART to terminal as a string.

Written by YS from we.easyelectronics.ru

You may freely use and redistribute this code any way you want,
but only at your own risk. Author gives no warranty and takes no 
responsibility on anything that could happen while using this code.

This code is written for ATmega48 running at 8MHz clock.
1-Wire pin is PB0, requires ~1K pullup.
*/

#include <avr/io.h>
#include <util/delay.h>
#include <avr/pgmspace.h>

#include "strfn.h"
#include "owbytefunc.h"

uint8_t msg[] PROGMEM = "1-Wire example - reading iButton serial:\r\n";
uint8_t errmsg[] PROGMEM = "No device detected.\r";
uint8_t valmsg[] PROGMEM = "CRC valid: ";
uint8_t ivalmsg[] PROGMEM = "CRC INVALID: ";

uint8_t rom_addr[8]={1,2,3,4,5,6,7,8};
uint8_t hexstr[35];

void UART_SendChar(uint8_t chr)
{
  while (!(UCSR0A & (1<<UDRE0)));
  UDR0=chr;
}

void SendRomString(uint8_t *romstr)
{
  uint8_t i=0;

  while (pgm_read_byte(&(romstr[i]))!=0)
  {
    UART_SendChar(pgm_read_byte(&(romstr[i])));
	i++;
  }
}

void SendRamString(uint8_t *ramstr)
{
  uint8_t i=0;

  while (ramstr[i]!=0)
  {
    UART_SendChar(ramstr[i]);
	i++;
  }
}

void AddrToASCII(void)
{
  uint8_t i,n=0;

  for (i=0; i<8; i++)
  {
    NumToHex(rom_addr[i],n,hexstr,0);
    hexstr[n+2]=':';
    n+=3;
  }

  hexstr[n-1]='\r';
  hexstr[n]='\n';
  hexstr[n+1]=0;
}

void main(void)
{
  UCSR0B=(1<<TXEN0);
  UBRR0=51; //9600BPS

  OW_InitBus();

  SendRomString(msg);

  while (1)
  {
	if (OW_Presence())
	{
	  if (OW_ReadRom(rom_addr))
	    SendRomString(valmsg);
      else
	    SendRomString(ivalmsg);

      AddrToASCII();
	  
	  SendRamString(hexstr);
    }
	else
	  SendRomString(errmsg);

	_delay_ms(1000);
  }
}
